export const blockSet = new Set([
    "discord.com",
    "youtube.com",
    "tiktok.com",
    "twitter.com",
    "x.com",
    "netflix.com",
    "primevideo.com",
    "hulu.com",
    "9animetv.to",
    "crunchyroll.com",
    "krunker.io",
    "reddit.com",
    "twitch.tv",
    "instagram.com",
    "snapchat.com",
    "facebook.com",
    "pinterest.com",
    "telegram.com",
    "tumblr.com",
    "ifunny.co",
    "9gag.com",
    "4chan.org",
    "omegle.com",
    "gab.com",
    "roblox.com",
    "pixiv.net"
]);

export const whitelistArr = [
    "music.youtube.com"
]